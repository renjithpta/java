package com.ibs.service.common.message;

public enum OrderType {

	PURCHASE, RETURN, EXCHANGE;
}
