package com.ibs.service.common.message;

public enum ShipmentType {

	CAR, PLANE, SHIP, TRAIN;
	
}
