package com.ibs.service.common.message;

public enum OrderStatus {

	NEW, PROCESSING, DONE, ERROR;
	
}
